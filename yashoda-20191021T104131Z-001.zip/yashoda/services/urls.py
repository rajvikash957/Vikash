from django.urls import path, re_path

from services import views

app_name = 'services'

urlpatterns = [
    path(r'', views.index, name='index'),

    #/services/book-appointment
    re_path('book-appointment/', views.bookAppoinment, name='book_appointment'),

    #/services/Cardiology
    re_path(r'(?P<category_name>[^%s]*)/', views.serviceInfo, name='service_info')
]
